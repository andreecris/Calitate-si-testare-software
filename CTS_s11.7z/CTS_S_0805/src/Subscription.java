// Interfata Component
public interface Subscription {
    String getDescription();
    double getPrice();
}
