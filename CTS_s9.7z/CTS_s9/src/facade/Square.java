package facade;

class Square {
    public void draw(){
        System.out.println("Patratul este desenat");
    }
}
