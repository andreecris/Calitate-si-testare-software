package adapter;

public class XmlParser {
    public void parseXml (String xml) {
        // code to parse XML
    }
}
