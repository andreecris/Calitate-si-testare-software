package adapter;

public interface JsonParser {
    void parseJson(String json);
}
