package facade2;

public class MasinaElectrica {
}
