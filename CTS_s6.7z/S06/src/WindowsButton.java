import java.awt.*;

public class WindowsButton extends Button {
}
