public class VeganPizza implements Pizza {
}
