public class Bear extends Animal {
}
