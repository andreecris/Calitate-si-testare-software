public class CheesePizza implements Pizza {
}
