public class PepperoniPizza implements Pizza {
}
