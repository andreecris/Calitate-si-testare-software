public interface Pizza {
}
