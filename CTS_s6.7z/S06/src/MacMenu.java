import java.awt.*;

public class MacMenu extends Menu {
}
