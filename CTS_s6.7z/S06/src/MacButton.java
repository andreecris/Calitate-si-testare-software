import java.awt.*;

public class MacButton extends Button {
}
