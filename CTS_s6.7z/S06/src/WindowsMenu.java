import java.awt.*;

public class WindowsMenu extends Menu {
}
