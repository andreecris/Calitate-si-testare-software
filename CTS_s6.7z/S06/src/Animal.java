public abstract class Animal {
}
